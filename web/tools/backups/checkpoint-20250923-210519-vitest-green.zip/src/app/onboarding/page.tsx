/** STUB:PHASE3
 * This is a scaffold placeholder. Replace with a real implementation.
 * Remove this header when done.
 */
export default function OnboardingPage() {
  return (
    <main>
      <h1>Onboarding</h1>
    </main>
  );
}
