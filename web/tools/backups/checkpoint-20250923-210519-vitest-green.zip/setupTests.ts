// web/test/setupTests.ts
import '@testing-library/jest-dom';
