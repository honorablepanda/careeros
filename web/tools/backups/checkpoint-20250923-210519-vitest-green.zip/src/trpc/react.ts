export { trpc as default, trpc } from './index';
