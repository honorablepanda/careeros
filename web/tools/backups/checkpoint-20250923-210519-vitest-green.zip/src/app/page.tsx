export default function Home() {
  return (
    <main>
      <h1>Welcome to CareerOS</h1>
    </main>
  );
}
