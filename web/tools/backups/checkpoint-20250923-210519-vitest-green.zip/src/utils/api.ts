// Stable client entry for web: import { trpc } from "../../utils/api"
export { trpc } from '../trpc';
